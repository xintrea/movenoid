#include <QDebug>
#include <iostream>
#include "MainWindow.h"
#include "ui_MainWindow.h"
#include "SettingsWindow.h"

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_settingsButton_clicked()
{
    static int counter=1;
    qDebug() << "Click to settings button" << counter;

    counter++;

    // SettingsWindow settingsWindow;
    // settingsWindow.exec();
}
